# Discord-Roblox-Bot Setup

## Voraussetzungen

- Node.js installiert
- Roblox-Server, der HTTP annehmen kann (z.B. über MessagingService / HttpService)

## Setup

1. `.env` Datei erstellen (siehe `.env.example`)
2. Abhängigkeiten installieren:

```
npm install discord.js axios express dotenv
```

3. Webhook starten:

```
node server.js
```

4. Bot starten:

```
node bot.js
```

## Slash Commands

- `/ban <user>`
- `/tempban <user> <dauer>`
- `/unban <user>`
- `/kick <user>`

## Roblox (Lua) Beispielscript

> Kommt separat mit Beschreibung.