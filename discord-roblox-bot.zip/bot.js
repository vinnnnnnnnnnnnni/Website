require('dotenv').config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

const commands = [
  new SlashCommandBuilder().setName('ban').setDescription('Einen Spieler bannen')
    .addStringOption(opt => opt.setName('user').setDescription('Roblox Username').setRequired(true)),
  new SlashCommandBuilder().setName('tempban').setDescription('Einen Spieler temporär bannen')
    .addStringOption(opt => opt.setName('user').setDescription('Roblox Username').setRequired(true))
    .addStringOption(opt => opt.setName('dauer').setDescription('Dauer z.B. 1d, 3h').setRequired(true)),
  new SlashCommandBuilder().setName('unban').setDescription('Einen Spieler entbannen')
    .addStringOption(opt => opt.setName('user').setDescription('Roblox Username').setRequired(true)),
  new SlashCommandBuilder().setName('kick').setDescription('Einen Spieler kicken')
    .addStringOption(opt => opt.setName('user').setDescription('Roblox Username').setRequired(true)),
].map(cmd => cmd.toJSON());

client.once('ready', async () => {
  console.log(`✅ Bot ist online als ${client.user.tag}`);

  // Slash Commands registrieren
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
  try {
    console.log('🔄 Registriere Slash-Commands...');
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log('✅ Slash-Commands registriert.');
  } catch (err) {
    console.error('❌ Fehler beim Registrieren der Commands:', err);
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = interaction.commandName;
  const username = interaction.options.getString('user');
  const duration = interaction.options.getString('dauer');
  const logChannel = await client.channels.fetch(process.env.LOG_CHANNEL_ID);

  await interaction.deferReply({ ephemeral: true });

  try {
    const robloxUser = await getRobloxUserInfo(username);
    if (!robloxUser) {
      await interaction.editReply('⚠️ Der angegebene Roblox-Nutzer konnte nicht gefunden werden.');
      return;
    }

    const payload = { user: username, action: command };
    if (duration) payload.duration = duration;

    await axios.post(process.env.API_URL, payload);

    const profileUrl = `https://www.roblox.com/users/${robloxUser.id}/profile`;
    const avatarUrl = `https://www.roblox.com/headshot-thumbnail/image?userId=${robloxUser.id}&width=420&height=420&format=png`;

    const embed = new EmbedBuilder()
      .setTitle(`✅ ${command.toUpperCase()} ausgeführt`)
      .addFields({ name: 'Benutzer', value: username, inline: true }, { name: 'Aktion', value: command, inline: true })
      .setThumbnail(avatarUrl)
      .setURL(profileUrl)
      .setFooter({ text: `Ausgeführt von ${interaction.user.tag}` })
      .setTimestamp()
      .setColor('Red');

    await interaction.editReply({ content: `✅ ${command} erfolgreich für ${username}.`, embeds: [embed] });
    if (logChannel) await logChannel.send({ embeds: [embed] });
  } catch (err) {
    console.error(err);
    await interaction.editReply('❌ Fehler beim Ausführen der Aktion.');
    if (logChannel) {
      const embed = new EmbedBuilder()
        .setTitle(`❌ Fehler bei ${command.toUpperCase()}`)
        .setDescription(`Benutzer: ${username}
Fehlermeldung: ${err.message}`)
        .setFooter({ text: `Ausgeführt von ${interaction.user.tag}` })
        .setColor('DarkRed')
        .setTimestamp();
      await logChannel.send({ embeds: [embed] });
    }
  }
});

async function getRobloxUserInfo(username) {
  try {
    const res = await axios.get(`https://users.roblox.com/v1/usernames/users`, {
      data: { usernames: [username], excludeBannedUsers: false }
    });
    return res.data.data[0];
  } catch (err) {
    return null;
  }
}

client.login(process.env.DISCORD_TOKEN);