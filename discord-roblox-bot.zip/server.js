const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post('/action', (req, res) => {
  const { user, action, duration } = req.body;
  console.log(`Empfangen: ${action} für ${user} ${duration || ''}`);
  res.status(200).json({ success: true });
});

app.listen(PORT, () => console.log(`Webhook läuft auf http://localhost:${PORT}`));